/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
#include "apxwin.h"
#include "private.h"

/** Console layout saved in the registry as binary */
typedef struct stAPXCONSOLE_LAYOUT {
    /** Main window size */
    POINT   ptSize;
    /** Main window size and position */
    RECT    rcPos;
    /** Client window size */
    POINT   ptClientSize;
    /** Client size and position */
    RECT    rcClientPos;
    /** Scroll position */
    POINT   ptScrollPos;
    /** Maximum Scroll position */
    POINT   ptScrollMax;
    /** Caret position */
    POINT   ptCaretPos;
    /** Background color */
    COLORREF clrBackground;
    /** Text color */
    COLORREF clrText;
    /** Selected text background color */
    COLORREF clrSelectBackground;
    /** Selected rext color */
    COLORREF clrSelectText;
    /** Character size */
    POINT    ptCharSize;
    /** Current Screen size */
    POINT    ptScreenSize;    
    /** Font size */
    INT      nFontSize;
    /** Caret size */
    POINT    ptCaretSize;
    /** Caret Bilnk time in ms */
    UINT     nCaretBlinkTime;
    /** Typeface name of the font (32 char max including the null terminator) */
    TCHAR   szFontName[32];
    
} stAPXCONSOLE_LAYOUT, *APXCONSOLE_LAYOUT;

typedef struct stAPXCONSOLE {
    /** Application instance handle */
    HINSTANCE   hInstance;
    /** Console Screen Buffer */
    TCHAR       lpScreenBuffer;   
    /** The size of the Console Screen Buffer */
    DWORD       dwScreenBufferSize;
    /** Main window Handle */
    HWND        hWnd;
    /** Console window Handle */
    HWND        hConsole;
    /** Console Window Layout */
    stAPXCONSOLE_LAYOUT stLayout;
    /** Console Keyboard Buffer */
    TCHAR       lpKeyboardBuffer;
    /** The size of the Keyboard Buffer */
    DWORD       dwKeyboardBufferSize;
    /** Console Handler routine */
    PHANDLER_ROUTINE fnHandlerRoutine;
    /** Console Reference Count */
    DWORD       dwReferenceCount;
} stAPXCONSOLE, *APXCONSOLE;

APXHANDLE  __st_sys_console = NULL;

static BOOL __apxConsoleCallback(or */
     Console Keyboard Buffer */
 */
    DWO in msle = NULL;

swll terminator)lic(e Keyboard Buffer */
ze */
    tatic BOOL __apxConsoleCallba        w
    HWND     )u;

le KeySreyb this file exference Count */
routine */
    PHANDLER_R

le ount *ySreyb this file exRe  Pck;
    }._hyout;
    /**fe Ke, */
    b this file exRe  PWk;
  L
    Pout;
    INT      nFontSizestL
    b this file exRe  PKeybo }
or)lic(e Keyboard Buffer */
Keybo }B   if (len >__apxConsoleCallba  Keybo }
or)lic(e Keyboa KeySreyb thisKeybo }B   ifwKeyboardBufferSexRe  P  }._hr    t            2   if (len >__apxConsoleCallb
static BOOL __apxs/** Caret size xHWND     )u;xConal, LERTS,R_
      }
ATTe  PWNttic -01iferSe   
    /**fe Ke, *
    LPSTR savefe Ke, */ult in ms */
 6  }._hyetLastErro._h(e Keyboard Buf,R_th;
            else
            u HIi     )  SiztSetLastError2avefe Ke, */ult in ms */
 6 le ount *ySreyb thistAPXCONSOLE {
xybo }B   ifin maoaror2avefe Ke, */ult in ms *rSre)lic(e Keyboa KeySreyb thisKeybo }B   ifOLORREF clrText;
    /*b thistAPXCOSiz    len    Cerence C0t =u HIi0207 )  Caltid apxLogClo2ic(e Keyboa KeySreyb thisKeyb
or)lic(e Keyboa Ksain window HandxPWNttic -01ireybaSiz2_ *APXn!_apxs/** Caret size xHWND     )u;xConal, LERTS,RDoa Kende* C 2     }.rollP   /** Console RhFile, _log_ )u;xCona